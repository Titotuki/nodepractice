// import express from 'express';
// const app = express();
// const port = 4000;
// // Middleware to read JSON data
// app.use(express.json());
// app.get('/', (req, res) => {
//   res.send('Welcome to Product API');
// });

// app.post('/products', (req, res) => {
//    const product = req.body;

//     console.log(product);

//     res.status(201).json({
//         message: 'Product created successfully',
//         data: product
//     });
// });
// app.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });

import express from "express";
import Product from "./models/Product.js";
import connectDB from "./db.js";

const app = express();

// Middleware to read JSON data
app.use(express.json());

// Connect to MongoDB
await connectDB();

// Test route
app.get("/", (req, res) => {
    res.send("CRUD API is running!");
});

// Start server
const PORT = 5000;
app.post("/api/products", async (req, res) => {
    try {
        const { name, price } = req.body;

        const product = await Product.create({
            name,
            price
        });

        res.status(201).json({
            message: "Product created successfully",
            product
        });

    } catch (error) {
        res.status(400).json({
            message: error.message
        });
    }
});
// Get all products
app.get("/api/products", async (req, res) => {
    try {
        const products = await Product.find();

        res.status(200).json({
            message: "Products fetched successfully",
            products
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

app.get("/api/products", async (req, res) => {
    try {
        const products = await Product.find();

        res.status(200).json({
            message: "Products fetched successfully",
            products
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});


app.get("/api/products/:id", async (req, res) => {
    const id = req.params.id;
    try {
        const product = await Product.findById(id);
       if(!product){
        res.status(404).send("Product is not found");
       }
       else{
         res.status(200).json({
            message: "Product fetched successfully",
            product
        });
       }
            
       
   

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

app.get("/api/products/:id", async (req, res) => {
    const id = req.params.id;
    try {
        const product = await Product.findById(id);
       if(!product){
        res.status(404).send("Product is not found");
       }
       else{
         res.status(200).json({
            message: "Product fetched successfully",
            product
        });
       }
            
       
   

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

app.put("/api/products/:id", async (req, res) => {
    const id = req.params.id;
    
    try {
       // const product = await Product.findByIdAndUpdate(id);
        console.log("1. Product ID:", id);
        console.log("2. Request Body:", req.body);
        const updatedProduct =  await Product.findByIdAndUpdate(
    id,
     req.body,
    { new:true }
);

       if(!updatedProduct){
        res.status(404).send("Product not updated");
       }
       else{
         res.status(200).json({
            message: "Product updated successfully",
            updatedProduct
        });
       }
            
       
   

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

app.patch("/api/products/:id", async (req, res) => {
    const id = req.params.id;
    
    try {
       // const product = await Product.findByIdAndUpdate(id);
        console.log("1. Product ID:", id);
        console.log("2. Request Body:", req.body);
        const updatedProduct =  await Product.findByIdAndUpdate(
    id,
     req.body,
   {returnDocument: 'after'} 
);

       if(!updatedProduct){
        res.status(404).send("Product not updated");
       }
       else{
         res.status(200).json({
            message: "price updated successfully",
            updatedProduct
        });
       }
            
       
   

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

app.patch("/api/products/:id", async (req, res) => {
    const id = req.params.id;
    
    try {
       // const product = await Product.findByIdAndUpdate(id);
        console.log("1. Product ID:", id);
        console.log("2. Request Body:", req.body);
        const updatedProduct =  await Product.findByIdAndUpdate(
    id,
     req.body,
   {returnDocument: 'after'} 
);

       if(!updatedProduct){
        res.status(404).send("Product not updated");
       }
       else{
         res.status(200).json({
            message: "price updated successfully",
            updatedProduct
        });
       }
            
       
   

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});